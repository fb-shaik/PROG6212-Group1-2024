﻿using System.ComponentModel.DataAnnotations;

namespace VendorInvoiceManagement.Models
{
    public class Vendor
    {
        public int VendorId { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(200)]
        public string Email { get; set; }

        [Required]
        [StringLength(100)]
        public string CompanyName { get; set; } // Vendor's company name

        [Required]
        [StringLength(200)]
        public string Address { get; set; } // Vendor's address

        [Required]
        [StringLength(15)]
        public string PhoneNumber { get; set; } // Vendor's contact number

        [Required]
        public string TaxIdentificationNumber { get; set; } // Vendor's tax ID for payment processing

        [Required]
        [StringLength(50)]
        public string BankName { get; set; } // Vendor's bank for payment

        [Required]
        [StringLength(20)]
        public string BankAccountNumber { get; set; } // Vendor's bank account number for payment

        [StringLength(100)]
        public string ContactPerson { get; set; } // Optional: Contact person for the vendor
    }
}
