﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace EF_App
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, IDisposable
    {
        // The database context used for all database operations
        private readonly BookContext _context;

        // Keeps track of the currently selected book in the DataGrid
        private Book _selectedBook;

        /// <summary>
        /// Constructor for MainWindow. Initializes the window and sets up the database.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent(); // Initialize the WPF components
            try
            {
                _context = new BookContext(); // Create a new database context
                _context.Database.EnsureCreated(); // Ensure the database is created
                LoadBooks(); // Load books from the database when the window is created
            }
            catch (Exception ex)
            {
                // Handle any errors during initialization
                MessageBox.Show($"Error initializing the application: {ex.Message}", 
                    "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error);
                Close(); // Close the application if initialization fails
            }
        }

        /// <summary>
        /// Loads books from the database and displays them in the DataGrid.
        /// </summary>
        private void LoadBooks()
        {
            try
            {
                // Load books and their associated authors, and set as the DataGrid's item source
                BooksDataGrid.ItemsSource = _context.Books.Include(b => b.Author).ToList();
            }
            catch (Exception ex)
            {
                // Handle any errors that occur while loading books
                MessageBox.Show($"Error loading books: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Event handler for the Refresh button. Reloads books from the database.
        /// </summary>
        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadBooks(); // Reload books from the database
        }

        /// <summary>
        /// Event handler for the Add New button. 
        /// Clears the input fields and prepares the UI for a new book entry.
        /// </summary>
        private void AddNewButton_Click(object sender, RoutedEventArgs e)
        {
            _selectedBook = null; // Clear the selected book
            TitleTextBox.Clear(); // Clear the title text box
            AuthorTextBox.Clear(); // Clear the author text box
            SaveButton.Content = "Create"; // Change the Save button text to indicate creation
        }

        /// <summary>
        /// Event handler for the Update button. Populates input fields with selected book details.
        /// </summary>
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedBook != null)
            {
                // If a book is selected, populate the text boxes with its details
                TitleTextBox.Text = _selectedBook.Title;
                AuthorTextBox.Text = _selectedBook.Author.Name;
                SaveButton.Content = "Update"; // Change the Save button text to indicate update
            }
            else
            {
                // Inform the user if no book is selected
                MessageBox.Show("Please select a book to update.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        /// <summary>
        /// Event handler for the Delete button. Deletes the selected book from the database.
        /// </summary>
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedBook != null)
            {
                try
                {
                    _context.Books.Remove(_selectedBook); // Remove the selected book from the context
                    _context.SaveChanges(); // Save changes to the database
                    LoadBooks(); // Reload the books list
                    _selectedBook = null; // Clear the selected book
                    TitleTextBox.Clear(); // Clear the title text box
                    AuthorTextBox.Clear(); // Clear the author text box
                    SaveButton.Content = "Create"; // Reset the Save button text
                    MessageBox.Show("Book deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (DbUpdateException ex)
                {
                    // Handle database-specific errors
                    MessageBox.Show($"Error deleting book: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception ex)
                {
                    // Handle any other unexpected errors
                    MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                // Inform the user if no book is selected for deletion
                MessageBox.Show("Please select a book to delete.", "No Selection", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        /// <summary>
        /// Event handler for the Save button. 
        /// Creates a new book or updates an existing one based on the current state.
        /// </summary>
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(TitleTextBox.Text) || string.IsNullOrWhiteSpace(AuthorTextBox.Text))
                {
                    MessageBox.Show("Title and Author cannot be empty.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                if (_selectedBook == null)
                {
                    // Create a new book
                    var author = new Author { Name = AuthorTextBox.Text };
                    var book = new Book { Title = TitleTextBox.Text, Author = author };
                    _context.Books.Add(book);
                    MessageBox.Show("New book created successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    // Update the existing book
                    _selectedBook.Title = TitleTextBox.Text;
                    _selectedBook.Author.Name = AuthorTextBox.Text;
                    _context.Update(_selectedBook);
                    MessageBox.Show("Book updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                _context.SaveChanges(); // Save changes to the database
                LoadBooks(); // Reload the books list
                SaveButton.Content = "Create"; // Reset the button text
                _selectedBook = null; // Clear the selection
                TitleTextBox.Clear(); // Clear the title text box
                AuthorTextBox.Clear(); // Clear the author text box
            }
            catch (DbUpdateException ex)
            {
                // Handle database-specific errors
                MessageBox.Show($"Error saving to database: {ex.Message}", "Database Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                // Handle any other unexpected errors
                MessageBox.Show($"Unexpected error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Event handler for when a selection in the DataGrid changes.
        /// </summary>
        private void BooksDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _selectedBook = BooksDataGrid.SelectedItem as Book; // Get the selected book
            if (_selectedBook != null)
            {
                // If a book is selected, populate the text boxes with its details
                TitleTextBox.Text = _selectedBook.Title;
                AuthorTextBox.Text = _selectedBook.Author.Name;
                SaveButton.Content = "Update"; // Change the Save button text to indicate update
            }
        }

        /// <summary>
        /// Implements IDisposable to properly dispose of the DbContext.
        /// </summary>
        public void Dispose()
        {
            _context?.Dispose(); // Dispose of the database context
        }

        /// <summary>
        /// Override OnClosed to ensure proper disposal of resources when the window is closed.
        /// </summary>
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            Dispose(); // Dispose of resources when the window is closed
        }
    }
}