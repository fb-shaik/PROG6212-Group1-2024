﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EF_App
{
    // This class represents our database context, inheriting from DbContext
    // DbContext is a fundamental class in EF Core that represents a session with the database
    public class BookContext : DbContext
    {
        // DbSet properties represent tables in the database
        // They're used to query and save instances of the respective entities
        public DbSet<Book> Books { get; set; }
        public DbSet<Author> Authors { get; set; }

        // This method is used to configure the database connection
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Here we're using SQL Server as our database provider
            // The connection string specifies where to find the database
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=BookDb;Trusted_Connection=True;");

            // Note: In a production application, you'd typically pass the connection string
            // as a parameter rather than hardcoding it here
        }

        // This method is used to further configure the model that EF Core creates
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Here we're using the Fluent API to configure the relationship between Book and Author
            modelBuilder.Entity<Book>()
                .HasOne(b => b.Author)  // A book has one author
                .WithMany()             // An author can have many books (but we haven't specified a navigation property on Author)
                .OnDelete(DeleteBehavior.Cascade);  // If an author is deleted, all their books will be deleted too

            // Note: We could add more configurations here, such as:
            // - Specifying table names
            // - Configuring indexes
            // - Setting up composite keys
            // - Configuring many-to-many relationships
        }
    }
}