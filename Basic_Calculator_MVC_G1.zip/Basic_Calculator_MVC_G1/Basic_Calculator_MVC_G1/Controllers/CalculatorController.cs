﻿using Basic_Calculator_MVC_G1.Models;
using Microsoft.AspNetCore.Mvc;

namespace Basic_Calculator_MVC_G1.Controllers
{
    public class CalculatorController : Controller
    {
        //GET
        public IActionResult Index()
        {
            return View();
        }
        //The POST method to handle form submission
        [HttpPost]
        public IActionResult Calculate(CalculatorModel model)
        {//check if the model is valid based on the attributes
            if (ModelState.IsValid)
            {
                try 
                {
                    //Perform the calculation using the Calculate method
                    model.Calculate();
                }
                catch (Exception ex)
                {//Handle any errors during the calculation
                 //& add to the model state
                 ModelState.AddModelError(string.Empty, ex.Message);
                }
            }
            //Return the Index view with the updated model
            return View("Index", model);
        }
    }
}
