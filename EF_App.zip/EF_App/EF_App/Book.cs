﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_App
{
    // This class represents a Book entity in our application
    // It will be mapped to a table in the database by Entity Framework Core
    public class Book
    {
        // The Id property will be recognized by EF Core as the primary key
        public int Id { get; set; }

        // This property will be mapped to a column in the database
        public string Title { get; set; }

        // This is a navigation property representing the relationship between Book and Author
        // It establishes a many-to-one relationship: many books can be associated with one author
        // EF Core will create a foreign key in the database based on this property
        public Author Author { get; set; }

        // This method overrides the default ToString() method
        // It's not directly related to EF Core, but can be useful for displaying book information
        public override string ToString()
        {
            return $"{Title} by {Author.Name}";
        }

        // Note: We could add more properties here to represent additional book attributes
        // For example: public int YearPublished { get; set; }

        // We could also add a property to represent the foreign key explicitly
        // For example: public int AuthorId { get; set; }
    }
}