﻿using System.ComponentModel.DataAnnotations;

namespace VendorInvoiceManagement.Models
{
    public class Invoice
    {
        public int InvoiceId { get; set; }

        [Required]
        public int VendorId { get; set; }
        public Vendor Vendor { get; set; }

        [Required]
        [Range(0.01, 1000000)]
        public decimal Amount { get; set; } // Using decimal for monetary values

        [Required]
        [DataType(DataType.Date)]
        public DateTime InvoiceDate { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; } // Payment due date

        [StringLength(1000)]
        public string Description { get; set; } // Description of services/products

        [Required]
        [DataType(DataType.Upload)]
        public string DocumentPath { get; set; }

        public bool IsApproved { get; set; } // Indicates whether the invoice is approved

        [DataType(DataType.Date)]
        public DateTime? ApprovedDate { get; set; } // Date of approval

        public bool IsPaid { get; set; } // Indicates if the invoice is paid

        [DataType(DataType.Date)]
        public DateTime? PaymentDate { get; set; } // Date of payment

        [StringLength(500)]
        public string PaymentMethod { get; set; } // Payment method (e.g., bank transfer)

        [StringLength(200)]
        public string ReferenceNumber { get; set; } // Payment reference number

        public bool IsOverdue => DueDate < DateTime.Now && !IsPaid; // Determines if the invoice is overdue
    }
}
