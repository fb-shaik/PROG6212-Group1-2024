﻿using Microsoft.AspNetCore.Mvc;
using System.IO;
using System.Threading.Tasks;
using VendorInvoiceManagement.Models;
using Microsoft.AspNetCore.Hosting;
using System.Collections.Generic;

namespace VendorInvoiceManagement.Controllers
{
    public class InvoiceController : Controller
    {
        private readonly IWebHostEnvironment _environment;

        public InvoiceController(IWebHostEnvironment environment)
        {
            _environment = environment;
        }

        // Simulating database with static lists for Vendors and Invoices
        private static List<Vendor> Vendors = new List<Vendor>();
        private static List<Invoice> Invoices = new List<Invoice>();

        // GET: Invoice/Submit
        public IActionResult Submit()
        {
            return View(new Invoice());
        }

        // POST: Invoice/Submit
        [HttpPost]
        public async Task<IActionResult> Submit(Invoice model)
        {
            if (ModelState.IsValid)
            {
                if (Request.Form.Files.Count > 0)
                {
                    var file = Request.Form.Files[0];
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");

                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var filePath = Path.Combine(uploadsFolder, file.FileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(fileStream);
                    }

                    model.DocumentPath = file.FileName;
                    model.IsApproved = false; // Default state is not approved
                    model.IsPaid = false; // Default state is unpaid
                    Invoices.Add(model);

                    return RedirectToAction("InvoiceSubmitted");
                }
                ModelState.AddModelError("", "Please upload a document.");
            }
            return View(model);
        }

        // GET: Invoice/InvoiceSubmitted
        public IActionResult InvoiceSubmitted()
        {
            return View();
        }

        // GET: Invoice/Approve
        public IActionResult Approve()
        {
            return View(Invoices.Where(i => !i.IsApproved).ToList());
        }

        // POST: Invoice/Approve
        [HttpPost]
        public IActionResult Approve(int invoiceId)
        {
            var invoice = Invoices.FirstOrDefault(i => i.InvoiceId == invoiceId);
            if (invoice != null)
            {
                invoice.IsApproved = true;
                invoice.ApprovedDate = DateTime.Now;
            }
            return RedirectToAction("Approve");
        }

        // GET: Invoice/DownloadDocument
        public IActionResult DownloadDocument(string filename)
        {
            var uploadsFolder = Path.Combine(_environment.WebRootPath, "uploads");
            var filePath = Path.Combine(uploadsFolder, filename);

            if (System.IO.File.Exists(filePath))
            {
                var fileBytes = System.IO.File.ReadAllBytes(filePath);
                return File(fileBytes, "application/octet-stream", filename);
            }

            return NotFound();
        }
    }
}