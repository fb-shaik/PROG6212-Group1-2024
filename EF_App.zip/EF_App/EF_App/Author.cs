﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_App
{
    // This class represents an Author entity in our application
    // It will be mapped to a table in the database by Entity Framework Core
    public class Author
    {
        // The Id property will be recognized by EF Core as the primary key
        // EF Core follows a convention where a property named 'Id' or '{ClassName}Id' is
        // automatically set as the primary key
        public int Id { get; set; }

        // This property will be mapped to a column in the database
        // By default, EF Core will create this as a non-nullable VARCHAR(MAX) column
        public string Name { get; set; }

        // Note: We could add more properties here to represent additional author attributes
        // For example: public DateTime DateOfBirth { get; set; }

        // We could also add a navigation property to represent the relationship with Books
        // For example: public ICollection<Book> Books { get; set; }
    }
}
